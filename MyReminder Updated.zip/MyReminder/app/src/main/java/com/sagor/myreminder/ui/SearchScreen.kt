package com.sagor.myreminder.ui

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.scheduling.Recurrence
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun SearchScreen(all: List<Reminder>, actions: Actions, onEdit: (Reminder) -> Unit, pad: PaddingValues) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var view by remember { mutableIntStateOf(0) }
    var priority by remember { mutableIntStateOf(-1) }
    var date by remember { mutableStateOf<LocalDate?>(null) }
    val now = LocalDateTime.now()
    val dateFilter = date

    val list = all.filter { r ->
        (q.isBlank() || r.title.contains(q, ignoreCase = true) || r.notes.contains(q, ignoreCase = true)) &&
            (priority < 0 || r.priority == priority) &&
            (dateFilter == null || Recurrence.occursOn(r, dateFilter)) &&
            when (view) {
                1 -> r.completed
                2 -> isOverdue(r, now)
                else -> true
            }
    }.let { l -> if (view == 0) l.sortedBy { it.epochDay } else l.sortedByDescending { it.epochDay } }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Search & History", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = q, onValueChange = { q = it },
                label = { Text("Search title or notes") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
        }
        item { ChipRow("Show", listOf("All", "Completed", "Overdue"), view) { view = it } }
        item {
            ChipRow("Priority", listOf("Any") + priorityLabels, priority + 1) { priority = it - 1 }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val d = dateFilter ?: LocalDate.now()
                    DatePickerDialog(
                        ctx, { _, y, m, day -> date = LocalDate.of(y, m + 1, day) },
                        d.year, d.monthValue - 1, d.dayOfMonth
                    ).show()
                }) {
                    Text(
                        if (dateFilter == null) "Filter by date"
                        else dateFilter.format(DateTimeFormatter.ofPattern("EEE, d MMM yyyy"))
                    )
                }
                if (dateFilter != null) TextButton(onClick = { date = null }) { Text("Clear") }
            }
        }
        item { SectionTitle(list.size.toString() + " result" + (if (list.size == 1) "" else "s")) }
        items(list, key = { it.id }) { r -> ReminderCard(r, subtitleFor(r, true), actions, onEdit) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
