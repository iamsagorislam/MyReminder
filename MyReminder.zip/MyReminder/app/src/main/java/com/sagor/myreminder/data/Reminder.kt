package com.sagor.myreminder.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * repeat: 0 once, 1 daily, 2 weekly, 3 weekdays, 4 weekends, 5 monthly, 6 every N days, 7 specific days
 * priority: 0 low, 1 medium, 2 high, 3 urgent
 * style: 0 standard, 1 important, 2 full-screen
 * Date and time are stored as local wall-clock values so a timezone change
 * only needs a reschedule, not a data migration.
 */
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String = "",
    val epochDay: Long,
    val minuteOfDay: Int,
    val repeat: Int = 0,
    val priority: Int = 1,
    val style: Int = 1,
    val completed: Boolean = false,
    val nagEnabled: Boolean = false,
    val nagMinutes: Int = 15,
    /** Extra times on the same date, minutes of day separated by commas, e.g. "720,1020". */
    @ColumnInfo(defaultValue = "''") val extraTimes: String = "",
    @ColumnInfo(defaultValue = "'Personal'") val category: String = "Personal",
    @ColumnInfo(defaultValue = "0") val isRoutine: Boolean = false,
    @ColumnInfo(defaultValue = "1") val enabled: Boolean = true,
    /** For "specific days": bit 0 = Monday ... bit 6 = Sunday. */
    @ColumnInfo(defaultValue = "0") val daysMask: Int = 0,
    @ColumnInfo(defaultValue = "1") val intervalDays: Int = 1
)

/** Every time this reminder should ring on its day, earliest first. */
fun Reminder.allTimes(): List<Int> =
    (listOf(minuteOfDay) + extraTimes.split(",").mapNotNull { it.trim().toIntOrNull() })
        .distinct().sorted()
