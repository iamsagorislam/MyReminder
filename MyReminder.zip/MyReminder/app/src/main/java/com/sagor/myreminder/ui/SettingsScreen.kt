package com.sagor.myreminder.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sagor.myreminder.data.AppDb
import com.sagor.myreminder.data.Backup
import com.sagor.myreminder.data.Categories
import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.scheduling.AlarmScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun StatusRow(label: String, ok: Boolean, onAllow: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        if (ok) Text("On", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        else TextButton(onClick = onAllow) { Text("Allow") }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            content()
        }
    }
}

@Composable
fun SettingsScreen(tick: Int, actions: Actions, pad: PaddingValues) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = remember { AppDb.get(ctx).dao() }
    var status by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Pair<List<Reminder>, List<String>>?>(null) }
    var custom by remember { mutableStateOf(Categories.custom(ctx)) }
    var newCat by remember { mutableStateOf("") }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        val text = Backup.toJson(dao.all(), Categories.custom(ctx))
                        ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                status = if (ok) "Backup saved." else "Could not save the backup."
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val parsed = withContext(Dispatchers.IO) {
                    try {
                        val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        if (text == null) null else Backup.fromJson(text)
                    } catch (e: Exception) {
                        null
                    }
                }
                if (parsed == null) status = "That file is not a valid My Reminder backup." else pending = parsed
            }
        }
    }

    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Restore backup?") },
            text = { Text("This replaces all current reminders with the " + p.first.size + " in the file.") },
            confirmButton = {
                TextButton(onClick = {
                    pending = null
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            dao.all().forEach { AlarmScheduler.cancelAll(ctx, it.id) }
                            dao.deleteAll()
                            p.first.forEach { r ->
                                val id = dao.insert(r.copy(id = 0))
                                AlarmScheduler.schedule(ctx, r.copy(id = id))
                            }
                            p.second.forEach { Categories.add(ctx, it) }
                        }
                        custom = Categories.custom(ctx)
                        status = "Restored " + p.first.size + " reminders."
                    }
                }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel") } }
        )
    }

    val notifOk = remember(tick) { Perm.notifOk(ctx) }
    val exactOk = remember(tick) { Perm.exactOk(ctx) }
    val fullOk = remember(tick) { Perm.fullOk(ctx) }
    val overlayOk = remember(tick) { Perm.overlayOk(ctx) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item {
            Section("Backup and restore") {
                Text(
                    "Save your reminders to a file (Downloads or Drive). Restore it after a reinstall.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(onClick = { exportLauncher.launch("MyReminder-backup.json") }, modifier = Modifier.fillMaxWidth()) {
                    Text("Backup / Export")
                }
                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("application/json", "text/*", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Restore / Import") }
                if (status.isNotEmpty()) Text(status, color = MaterialTheme.colorScheme.primary)
            }
        }
        item {
            Section("Categories") {
                Text("Built in: Personal, Work, Business, Health & Fitness, Important, Other", fontSize = 13.sp)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newCat, onValueChange = { newCat = it },
                        label = { Text("New category") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    Button(
                        enabled = newCat.isNotBlank(),
                        onClick = {
                            Categories.add(ctx, newCat)
                            custom = Categories.custom(ctx)
                            newCat = ""
                        }
                    ) { Text("Add") }
                }
            }
        }
        items(custom, key = { "cat_$it" }) { name ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(name, Modifier.weight(1f))
                TextButton(onClick = {
                    Categories.remove(ctx, name)
                    custom = Categories.custom(ctx)
                }) { Text("Remove") }
            }
        }
        item {
            Section("Reliability checklist") {
                StatusRow("Notifications", notifOk) { Perm.openNotif(ctx) }
                StatusRow("Exact alarms", exactOk) { Perm.openExact(ctx) }
                StatusRow("Full-screen on lock screen", fullOk) { Perm.openFull(ctx) }
                StatusRow("Display over other apps", overlayOk) { Perm.openOverlay(ctx) }
                Text(
                    "vivo / iQOO: Settings > Battery > Background power consumption > My Reminder > Allow. " +
                        "Also allow Autostart, and turn off \"Manage app if unused\" in the app's permissions.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(onClick = { Perm.openAppInfo(ctx) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Open app settings")
                }
            }
        }
        item {
            Section("Test") {
                Button(onClick = { actions.testAlert() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Test full-screen alert (10 sec)")
                }
                Text(
                    "Adds a Test alert reminder. Delete it from Search & History afterwards.",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
