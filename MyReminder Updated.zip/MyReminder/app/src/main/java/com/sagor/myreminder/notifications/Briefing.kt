package com.sagor.myreminder.notifications

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.sagor.myreminder.MainActivity
import com.sagor.myreminder.R
import com.sagor.myreminder.data.AppDb
import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.data.allTimes
import com.sagor.myreminder.scheduling.AlarmScheduler
import com.sagor.myreminder.scheduling.Recurrence
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

object Briefing {
    const val MORNING = "morning"
    const val EVENING = "evening"

    private fun prefs(c: Context) = c.getSharedPreferences("briefing", Context.MODE_PRIVATE)

    fun on(c: Context, kind: String): Boolean = prefs(c).getBoolean(kind + "_on", false)

    /** Minute of day. Defaults: morning 7:30 AM, evening 9:30 PM. */
    fun minute(c: Context, kind: String): Int =
        prefs(c).getInt(kind + "_min", if (kind == MORNING) 450 else 1290)

    fun set(c: Context, kind: String, on: Boolean, minute: Int) {
        prefs(c).edit().putBoolean(kind + "_on", on).putInt(kind + "_min", minute).apply()
        schedule(c, kind)
    }

    fun scheduleAll(c: Context) {
        schedule(c, MORNING)
        schedule(c, EVENING)
    }

    private fun pi(c: Context, kind: String): PendingIntent {
        val i = Intent(c, BriefingReceiver::class.java).putExtra("kind", kind)
        return PendingIntent.getBroadcast(
            c, if (kind == MORNING) 900001 else 900002, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(c: Context, kind: String) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(pi(c, kind))
        if (!on(c, kind)) return
        val m = minute(c, kind)
        var t = LocalDate.now().atTime(m / 60, m % 60)
        if (!t.isAfter(LocalDateTime.now())) t = t.plusDays(1)
        val millis = t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val p = pi(c, kind)
        try {
            if (AlarmScheduler.canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, p)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, p)
        }
    }
}

class BriefingReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val kind = i.getStringExtra("kind") ?: return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val (title, body) = compose(AppDb.get(c).dao().all(), kind)
                val nm = c.getSystemService(NotificationManager::class.java)
                val open = PendingIntent.getActivity(
                    c, 0, Intent(c, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                nm.notify(
                    if (kind == Briefing.MORNING) 9001 else 9002,
                    NotificationCompat.Builder(c, NotificationHelper.CH_BRIEF)
                        .setSmallIcon(R.drawable.ic_notif)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                        .setContentIntent(open)
                        .setAutoCancel(true)
                        .build()
                )
            } finally {
                Briefing.schedule(c, kind)
                pending.finish()
            }
        }
    }

    private fun bn(n: Int): String = n.toString().map { '\u09E6' + (it - '0') }.joinToString("")

    private fun compose(all: List<Reminder>, kind: String): Pair<String, String> {
        val today = LocalDate.now()
        val active = all.filter { it.enabled && !it.completed && !it.isRoutine }
        val todays = active.filter { Recurrence.occursOn(it, today) }
        if (kind == Briefing.MORNING) {
            if (todays.isEmpty()) return "\u09B6\u09C1\u09AD \u09B8\u0995\u09BE\u09B2" to "\u0986\u099C \u0995\u09CB\u09A8\u09CB \u0995\u09BE\u099C \u09A8\u09C7\u0987\u0964"
            val first = todays.minByOrNull { it.allTimes().first() }!!
            return "\u09B6\u09C1\u09AD \u09B8\u0995\u09BE\u09B2" to
                "\u0986\u099C " + bn(todays.size) + "\u099F\u09BE \u0995\u09BE\u099C \u0986\u099B\u09C7\u0964 \u09AA\u09CD\u09B0\u09A5\u09AE\u099F\u09BE: " +
                first.title + " (" + NotificationHelper.timeText(first.allTimes().first()) + ")"
        }
        val open = todays.count { it.repeat == 0 }
        val tomorrow = active.count { Recurrence.occursOn(it, today.plusDays(1)) }
        val a = if (open == 0) "\u0986\u099C\u0995\u09C7\u09B0 \u09B8\u09AC \u0995\u09BE\u099C \u09B6\u09C7\u09B7\u0964"
        else "\u0986\u099C " + bn(open) + "\u099F\u09BE \u0995\u09BE\u099C \u098F\u0996\u09A8\u09CB \u09B6\u09C7\u09B7 \u09B9\u09DF\u09A8\u09BF\u0964"
        return "\u09B0\u09BE\u09A4\u09C7\u09B0 \u09B0\u09BF\u09AD\u09BF\u0989" to
            a + " \u0995\u09BE\u09B2 " + bn(tomorrow) + "\u099F\u09BE \u0995\u09BE\u099C \u0986\u099B\u09C7\u0964"
    }
}
