package com.sagor.myreminder.ui

import com.sagor.myreminder.data.Reminder
import java.time.DayOfWeek
import java.time.LocalDateTime
import java.time.LocalTime

/** Best-effort reader for spoken Bangla like "kal sokal 9tay doctor er kache jawa". The result is shown for editing. */
object VoiceParser {
    private const val YA = "\u09DF" // য়

    private val saare = "\u09B8\u09BE\u09DC\u09C7" // সাড়ে
    private val soya = "\u09B8\u09CB\u09DF\u09BE" // সোয়া
    private val pone = "\u09AA\u09CC\u09A8\u09C7" // পৌনে

    private val numberWords = mapOf(
        "\u098F\u0995" to 1, // এক
        "\u09A6\u09C1\u0987" to 2, // দুই
        "\u09A4\u09BF\u09A8" to 3, // তিন
        "\u099A\u09BE\u09B0" to 4, // চার
        "\u09AA\u09BE\u0981\u099A" to 5, // পাঁচ
        "\u099B$YA" to 6, // ছয়
        "\u09B8\u09BE\u09A4" to 7, // সাত
        "\u0986\u099F" to 8, // আট
        "\u09A8$YA" to 9, // নয়
        "\u09A6\u09B6" to 10, // দশ
        "\u098F\u0997\u09BE\u09B0\u09CB" to 11, // এগারো
        "\u09AC\u09BE\u09B0\u09CB" to 12 // বারো
    )

    private val timeRe = Regex(
        "(" + saare + "|" + soya + "|" + pone + ")?\\s*(\\d{1,2})(?::(\\d{2}))?\\s*\u099F\u09BE(?:" + YA + "|\u09B0|\\s*\u09AC\u09BE\u099C\u09C7)"
    )
    private val colonRe = Regex("(\\d{1,2}):(\\d{2})")

    private val tomorrowWords = setOf(
        "\u0995\u09BE\u09B2", "\u0995\u09BE\u09B2\u0995\u09C7",
        "\u0986\u0997\u09BE\u09AE\u09C0\u0995\u09BE\u09B2", "\u0986\u0997\u09BE\u09AE\u09BF\u0995\u09BE\u09B2"
    )
    private val todayWords = setOf("\u0986\u099C", "\u0986\u099C\u0995\u09C7")
    private val dayAfterWords = setOf("\u09AA\u09B0\u09B6\u09C1", "\u09AA\u09B0\u09B6\u09C1\u09A6\u09BF\u09A8")
    private val fillers = setOf(
        "\u0986\u09AE\u09BE\u0995\u09C7", "\u09AE\u09A8\u09C7", "\u0995\u09B0\u09BF\u09DF\u09C7",
        "\u09A6\u09BF\u0993", "\u09A6\u09BE\u0993", "\u09B0\u09BF\u09AE\u09BE\u0987\u09A8\u09CD\u09A1",
        "\u09B0\u09BF\u09AE\u09BE\u0987\u09A8\u09CD\u09A1\u09BE\u09B0", "\u0995\u09B0\u09CB"
    )

    private val weekdays = listOf(
        "\u09B0\u09AC\u09BF\u09AC\u09BE\u09B0" to DayOfWeek.SUNDAY,
        "\u09B8\u09CB\u09AE\u09AC\u09BE\u09B0" to DayOfWeek.MONDAY,
        "\u09AE\u0999\u09CD\u0997\u09B2\u09AC\u09BE\u09B0" to DayOfWeek.TUESDAY,
        "\u09AC\u09C1\u09A7\u09AC\u09BE\u09B0" to DayOfWeek.WEDNESDAY,
        "\u09AC\u09C3\u09B9\u09B8\u09CD\u09AA\u09A4\u09BF\u09AC\u09BE\u09B0" to DayOfWeek.THURSDAY,
        "\u09B6\u09C1\u0995\u09CD\u09B0\u09AC\u09BE\u09B0" to DayOfWeek.FRIDAY,
        "\u09B6\u09A8\u09BF\u09AC\u09BE\u09B0" to DayOfWeek.SATURDAY
    )

    private fun norm(s: String): String {
        var t = s.replace("\u09AF\u09BC", "\u09DF").replace("\u09A1\u09BC", "\u09DC").replace("\u09A2\u09BC", "\u09DD")
        val digits = "\u09E6\u09E7\u09E8\u09E9\u09EA\u09EB\u09EC\u09ED\u09EE\u09EF"
        t = t.map { ch ->
            val i = digits.indexOf(ch)
            if (i >= 0) ('0' + i) else ch
        }.joinToString("")
        return t
    }

    private fun partOf(w: String): String? = when {
        w.startsWith("\u09B8\u0995\u09BE\u09B2") -> "am" // সকাল
        w.startsWith("\u09AD\u09CB\u09B0") -> "am" // ভোর
        w.startsWith("\u09A6\u09C1\u09AA\u09C1\u09B0") -> "noon" // দুপুর
        w.startsWith("\u09AC\u09BF\u0995\u09BE\u09B2") || w.startsWith("\u09AC\u09BF\u0995\u09C7\u09B2") -> "pm" // বিকাল, বিকেল
        w.startsWith("\u09B8\u09A8\u09CD\u09A7") -> "pm" // সন্ধ্যা
        w.startsWith("\u09B0\u09BE\u09A4") -> "night" // রাত
        else -> null
    }

    fun parse(text: String, now: LocalDateTime): Reminder {
        var t = norm(text.trim())
        for ((w, n) in numberWords) {
            t = Regex(Regex.escape(w) + "(?=\u099F\u09BE(?:" + YA + "|\u09B0))").replace(t, n.toString())
        }
        var hour = -1
        var minute = 0
        val m = timeRe.find(t)
        if (m != null) {
            val frac = m.groupValues[1]
            hour = m.groupValues[2].toInt()
            minute = m.groupValues[3].toIntOrNull() ?: 0
            if (frac == saare) minute = 30
            else if (frac == soya) minute = 15
            else if (frac == pone) { hour -= 1; minute = 45 }
            t = t.removeRange(m.range)
        } else {
            val c = colonRe.find(t)
            if (c != null) {
                hour = c.groupValues[1].toInt()
                minute = c.groupValues[2].toInt()
                t = t.removeRange(c.range)
            }
        }
        if (hour !in 0..23 || minute !in 0..59) { hour = -1; minute = 0 }

        var offset: Int? = null
        var dow: DayOfWeek? = null
        var part: String? = null
        var todayWord = false
        val rest = mutableListOf<String>()
        for (tok in t.split(Regex("\\s+")).filter { it.isNotBlank() }) {
            val w = tok.trim(',', '.', '\u0964', '?', '!')
            val wd = weekdays.firstOrNull { w.startsWith(it.first) }?.second
            val p = partOf(w)
            when {
                w in todayWords -> todayWord = true
                w in tomorrowWords -> offset = 1
                w in dayAfterWords -> offset = 2
                wd != null -> dow = wd
                p != null -> part = p
                w in fillers -> {}
                else -> rest.add(tok)
            }
        }

        if (hour >= 0) {
            when (part) {
                "noon" -> { if (hour in 1..5) hour += 12 }
                "pm" -> { if (hour < 12) hour += 12 }
                "night" -> { if (hour == 12) hour = 0 else if (hour in 6..11) hour += 12 }
                else -> {}
            }
        }

        val today = now.toLocalDate()
        val off = offset
        val wanted = dow
        val explicit = off != null || wanted != null || todayWord
        var date = when {
            off != null -> today.plusDays(off.toLong())
            wanted != null -> {
                var d = today.plusDays(1)
                while (d.dayOfWeek != wanted) d = d.plusDays(1)
                d
            }
            else -> today
        }
        if (hour < 0) {
            hour = if (date == today) now.plusHours(1).hour else 9
            minute = 0
        } else if (!explicit) {
            var at = LocalDateTime.of(date, LocalTime.of(hour, minute))
            if (at.isBefore(now) && part == null && hour in 1..11) at = at.plusHours(12)
            if (at.isBefore(now)) at = at.plusDays(1)
            date = at.toLocalDate()
            hour = at.hour
        }

        return Reminder(
            title = rest.joinToString(" ").ifBlank { text.trim() },
            epochDay = date.toEpochDay(),
            minuteOfDay = hour * 60 + minute
        )
    }
}
