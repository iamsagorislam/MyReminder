package com.sagor.myreminder.notifications

import android.content.Intent
import android.net.Uri

object ContactActions {
    private fun digits(p: String) = p.filter { it.isDigit() }

    /** WhatsApp wants the international form, e.g. 01712345678 becomes 8801712345678. */
    fun waNumber(p: String): String {
        val d = digits(p)
        return when {
            d.startsWith("880") -> d
            d.startsWith("0") -> "88$d"
            d.length == 10 && d.startsWith("1") -> "880$d"
            else -> d
        }
    }

    fun dial(phone: String): Intent =
        Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone.trim())))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun whatsapp(phone: String): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + waNumber(phone)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
