package com.sagor.myreminder.notifications

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.sagor.myreminder.R
import com.sagor.myreminder.data.AppDb
import com.sagor.myreminder.data.Reminder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Draws the reminder over everything, so it appears even while the phone is in use. */
class OverlayService : Service() {
    private var root: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = NotificationCompat.Builder(this, NotificationHelper.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Reminder alert")
            .setOngoing(true)
            .build()
        startForeground(77, n)
        val id = intent?.getLongExtra("id", -1) ?: -1
        CoroutineScope(Dispatchers.IO).launch {
            val r = AppDb.get(applicationContext).dao().get(id)
            withContext(Dispatchers.Main) { if (r == null) stopSelf() else show(r) }
        }
        return START_NOT_STICKY
    }

    private fun show(r: Reminder) {
        hide()
        val wm = getSystemService(WindowManager::class.java)
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        fun label(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = t
            setTextColor(Color.WHITE)
            textSize = size
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#F2101828"))
            setPadding(px(24), px(24), px(24), px(24))
        }
        col.addView(label(NotificationHelper.timeText(r), 20f))
        col.addView(label(r.title, 34f, true).apply { setPadding(0, px(12), 0, px(12)) })
        if (r.notes.isNotBlank()) col.addView(label(r.notes, 18f))

        val full = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        col.addView(
            button("Complete") { done { ReminderActions.complete(applicationContext, r.id) } },
            LinearLayout.LayoutParams(full).apply { topMargin = px(32) }
        )
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(5 to "5m", 10 to "10m", 15 to "15m", 30 to "30m", 60 to "1h").forEach { (m, l) ->
            row.addView(
                button(l) { done { ReminderActions.snooze(applicationContext, r.id, m) } },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        col.addView(row, LinearLayout.LayoutParams(full).apply { topMargin = px(12) })
        col.addView(button("Dismiss") { done { ReminderActions.dismiss(applicationContext, r.id) } }, full)

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(col, lp)
            root = col
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun done(block: suspend () -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            block()
            withContext(Dispatchers.Main) {
                hide()
                stopSelf()
            }
        }
    }

    private fun hide() {
        root?.let {
            try {
                getSystemService(WindowManager::class.java).removeView(it)
            } catch (e: Exception) {
            }
        }
        root = null
    }

    override fun onDestroy() {
        hide()
        super.onDestroy()
    }
}
