package com.sagor.myreminder.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.data.allTimes
import com.sagor.myreminder.scheduling.Recurrence
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

private fun LazyListScope.daySection(
    date: LocalDate,
    list: List<Reminder>,
    actions: Actions,
    onEdit: (Reminder) -> Unit
) {
    item(key = "day_$date") {
        SectionTitle(dayLabel(date) + "  " + date.format(DateTimeFormatter.ofPattern("d MMM yyyy")))
    }
    if (list.isEmpty()) {
        item(key = "none_$date") {
            Text("No reminders", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    items(list, key = { "c_" + date + "_" + it.id }) { r -> ReminderCard(r, subtitleFor(r, false), actions, onEdit) }
}

@Composable
private fun DayCell(
    modifier: Modifier,
    num: Int,
    selected: Boolean,
    isToday: Boolean,
    hasItems: Boolean,
    onClick: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val bg = when {
        selected -> primary
        isToday -> primary.copy(alpha = 0.15f)
        else -> androidx.compose.ui.graphics.Color.Transparent
    }
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Box(
        modifier.aspectRatio(1f).padding(3.dp).clip(CircleShape).background(bg).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(num.toString(), color = fg, fontSize = 14.sp)
            if (hasItems) {
                Box(Modifier.size(5.dp).clip(CircleShape).background(if (selected) fg else primary))
            }
        }
    }
}

@Composable
fun CalendarScreen(all: List<Reminder>, actions: Actions, onEdit: (Reminder) -> Unit, pad: PaddingValues) {
    var mode by remember { mutableIntStateOf(2) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    val visible = all.filter { it.enabled }
    fun on(d: LocalDate): List<Reminder> =
        visible.filter { Recurrence.occursOn(it, d) }.sortedBy { it.allTimes().first() }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Calendar", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Day", "Week", "Month").forEachIndexed { i, l ->
                    FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(l) })
                }
            }
        }
        when (mode) {
            0 -> {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { selected = selected.minusDays(1) }) { Text("<") }
                        Text(
                            selected.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
                            Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold
                        )
                        TextButton(onClick = { selected = selected.plusDays(1) }) { Text(">") }
                    }
                }
                daySection(selected, on(selected), actions, onEdit)
            }
            1 -> {
                val weekStart = selected.minusDays(selected.dayOfWeek.value - 1L)
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { selected = selected.minusDays(7) }) { Text("<") }
                        Text(
                            weekStart.format(DateTimeFormatter.ofPattern("d MMM")) + " - " +
                                weekStart.plusDays(6).format(DateTimeFormatter.ofPattern("d MMM")),
                            Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold
                        )
                        TextButton(onClick = { selected = selected.plusDays(7) }) { Text(">") }
                    }
                }
                for (i in 0..6) {
                    val d = weekStart.plusDays(i.toLong())
                    daySection(d, on(d), actions, onEdit)
                }
            }
            else -> {
                item {
                    val first = month.atDay(1)
                    val offset = first.dayOfWeek.value - 1
                    val len = month.lengthOfMonth()
                    val rows = (offset + len + 6) / 7
                    val today = LocalDate.now()
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { month = month.minusMonths(1) }) { Text("<") }
                            Text(
                                month.format(DateTimeFormatter.ofPattern("MMMM yyyy")),
                                Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold
                            )
                            TextButton(onClick = { month = month.plusMonths(1) }) { Text(">") }
                        }
                        Row {
                            dayLabels.forEach {
                                Text(
                                    it.take(2), Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        for (w in 0 until rows) {
                            Row {
                                for (c in 0 until 7) {
                                    val num = w * 7 + c - offset + 1
                                    if (num in 1..len) {
                                        val d = month.atDay(num)
                                        DayCell(
                                            modifier = Modifier.weight(1f),
                                            num = num,
                                            selected = d == selected,
                                            isToday = d == today,
                                            hasItems = visible.any { Recurrence.occursOn(it, d) },
                                            onClick = { selected = d }
                                        )
                                    } else {
                                        Spacer(Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
                daySection(selected, on(selected), actions, onEdit)
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}
