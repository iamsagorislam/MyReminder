package com.sagor.myreminder.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * repeat: 0 once, 1 daily, 2 weekly, 3 weekdays, 4 weekends, 5 monthly, 6 every N days, 7 specific days
 * priority: 0 low, 1 medium, 2 high, 3 urgent
 * style: 0 standard, 1 important, 2 full-screen
 * Date and time are stored as local wall-clock values so a timezone change
 * only needs a reschedule, not a data migration.
 */
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String = "",
    val epochDay: Long,
    val minuteOfDay: Int,
    val repeat: Int = 0,
    val priority: Int = 1,
    val style: Int = 1,
    val completed: Boolean = false,
    val nagEnabled: Boolean = false,
    val nagMinutes: Int = 15,
    /** Extra times on the same date, minutes of day separated by commas, e.g. "720,1020". */
    @ColumnInfo(defaultValue = "''") val extraTimes: String = "",
    @ColumnInfo(defaultValue = "'Personal'") val category: String = "Personal",
    @ColumnInfo(defaultValue = "0") val isRoutine: Boolean = false,
    @ColumnInfo(defaultValue = "1") val enabled: Boolean = true,
    /** For "specific days": bit 0 = Monday ... bit 6 = Sunday. */
    @ColumnInfo(defaultValue = "0") val daysMask: Int = 0,
    @ColumnInfo(defaultValue = "1") val intervalDays: Int = 1,
    /** Checklist lines: "0|text" (open) or "1|text" (done), one per line. */
    @ColumnInfo(defaultValue = "''") val checklist: String = "",
    @ColumnInfo(defaultValue = "''") val phone: String = ""
)

data class CheckItem(val done: Boolean, val text: String)

fun Reminder.checkItems(): List<CheckItem> =
    checklist.split("\n").filter { it.length > 2 }.map { CheckItem(it.startsWith("1|"), it.drop(2)) }

fun encodeChecklist(items: List<CheckItem>): String =
    items.filter { it.text.isNotBlank() }
        .joinToString("\n") { (if (it.done) "1|" else "0|") + it.text.replace("\n", " ").trim() }

/** Every time this reminder should ring on its day, earliest first. */
fun Reminder.allTimes(): List<Int> =
    (listOf(minuteOfDay) + extraTimes.split(",").mapNotNull { it.trim().toIntOrNull() })
        .distinct().sorted()
