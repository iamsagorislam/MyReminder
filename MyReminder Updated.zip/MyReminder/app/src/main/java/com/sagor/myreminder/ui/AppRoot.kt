package com.sagor.myreminder.ui

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.sagor.myreminder.data.AppDb
import com.sagor.myreminder.data.Reminder
import java.time.LocalDateTime

@Composable
fun AppRoot(tick: Int) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).dao() }
    val all by dao.observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val actions = remember { Actions(ctx, dao, scope) }

    var tab by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Reminder?>(null) }
    var routineMode by remember { mutableStateOf(false) }
    var showDialog by remember { mutableStateOf(false) }

    val onEdit: (Reminder) -> Unit = { r ->
        editing = r
        routineMode = r.isRoutine
        showDialog = true
    }

    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (res.resultCode == Activity.RESULT_OK && !spoken.isNullOrBlank()) {
            editing = VoiceParser.parse(spoken, LocalDateTime.now())
            routineMode = false
            showDialog = true
        }
    }
    val startVoice: () -> Unit = {
        try {
            voiceLauncher.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "\u09AC\u09B2\u09C1\u09A8, \u0995\u09C0 \u09AE\u09A8\u09C7 \u0995\u09B0\u09BE\u09A4\u09C7 \u09B9\u09AC\u09C7")
            )
        } catch (e: Exception) {
            Toast.makeText(ctx, "Voice input is not available on this phone", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = "Calendar") },
                    label = { Text("Calendar") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.Refresh, contentDescription = "Routine") },
                    label = { Text("Routine") }
                )
                NavigationBarItem(
                    selected = tab == 3, onClick = { tab = 3 },
                    icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    label = { Text("Search") }
                )
                NavigationBarItem(
                    selected = tab == 4, onClick = { tab = 4 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") }
                )
            }
        },
        floatingActionButton = {
            if (tab <= 2) {
                FloatingActionButton(onClick = {
                    editing = null
                    routineMode = tab == 2
                    showDialog = true
                }) { Icon(Icons.Default.Add, contentDescription = "New") }
            }
        }
    ) { pad: PaddingValues ->
        Crossfade(targetState = tab, label = "tabs") { t ->
            when (t) {
                0 -> HomeScreen(all, tick, actions, onEdit, startVoice, pad)
                1 -> CalendarScreen(all, actions, onEdit, pad)
                2 -> RoutineScreen(all, actions, onEdit, pad)
                3 -> SearchScreen(all, actions, onEdit, pad)
                else -> SettingsScreen(tick, actions, pad)
            }
        }
    }

    if (showDialog) {
        ReminderDialog(
            initial = editing,
            routine = routineMode,
            onDismiss = { showDialog = false },
            onSave = { r ->
                showDialog = false
                actions.save(r)
            }
        )
    }
}
