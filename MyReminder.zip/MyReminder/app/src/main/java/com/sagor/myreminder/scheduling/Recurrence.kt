package com.sagor.myreminder.scheduling

import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.data.allTimes
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

object Recurrence {
    /** Next trigger strictly after [now], or null if a one-time reminder is already in the past. */
    fun next(r: Reminder, now: LocalDateTime = LocalDateTime.now()): LocalDateTime? {
        val base = LocalDate.ofEpochDay(r.epochDay)
        val times = r.allTimes().map { LocalTime.of(it / 60, it % 60) }
        if (r.repeat == 0) {
            return times.map { LocalDateTime.of(base, it) }.firstOrNull { it.isAfter(now) }
        }
        var d = if (now.toLocalDate().isAfter(base)) now.toLocalDate() else base
        repeat(9) {
            if (matches(r.repeat, base, d)) {
                val c = times.map { LocalDateTime.of(d, it) }.firstOrNull { it.isAfter(now) }
                if (c != null) return c
            }
            d = d.plusDays(1)
        }
        return null
    }

    private fun matches(rule: Int, base: LocalDate, d: LocalDate): Boolean = when (rule) {
        1 -> true
        2 -> d.dayOfWeek == base.dayOfWeek
        3 -> d.dayOfWeek.value <= 5
        4 -> d.dayOfWeek.value >= 6
        else -> false
    }
}
