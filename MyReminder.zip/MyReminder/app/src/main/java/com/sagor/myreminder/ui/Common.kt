package com.sagor.myreminder.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.data.ReminderDao
import com.sagor.myreminder.data.allTimes
import com.sagor.myreminder.notifications.NotificationHelper
import com.sagor.myreminder.notifications.ReminderActions
import com.sagor.myreminder.scheduling.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter

val repeatLabels = listOf(
    "Once", "Daily", "Weekly", "Weekdays", "Weekends", "Monthly", "Every N days", "Specific days"
)
val priorityLabels = listOf("Low", "Medium", "High", "Urgent")
val styleLabels = listOf("Quiet (vibrate)", "Pop-up (tone)", "Alarm (full-screen)")
val priorityColors = listOf(Color(0xFF8A94A6), Color(0xFF1E6BFF), Color(0xFFF59E0B), Color(0xFFE5393B))
val dayLabels = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

fun lastDt(r: Reminder): LocalDateTime {
    val last = r.allTimes().last()
    return LocalDateTime.of(LocalDate.ofEpochDay(r.epochDay), LocalTime.of(last / 60, last % 60))
}

fun isOverdue(r: Reminder, now: LocalDateTime): Boolean =
    !r.completed && r.enabled && r.repeat == 0 && lastDt(r).isBefore(now)

fun timesText(r: Reminder): String =
    r.allTimes().joinToString(", ") { NotificationHelper.timeText(it) }

fun repeatText(r: Reminder): String = when (r.repeat) {
    0 -> ""
    6 -> "Every " + r.intervalDays + " days"
    7 -> dayLabels.filterIndexed { i, _ -> ((r.daysMask shr i) and 1) == 1 }.joinToString(" ")
    else -> repeatLabels[r.repeat]
}

fun dayLabel(d: LocalDate): String {
    val t = LocalDate.now()
    return when (d) {
        t -> "Today"
        t.plusDays(1) -> "Tomorrow"
        t.minusDays(1) -> "Yesterday"
        else -> d.format(DateTimeFormatter.ofPattern("EEE, d MMM"))
    }
}

fun subtitleFor(r: Reminder, withDay: Boolean): String {
    val parts = mutableListOf<String>()
    if (withDay && r.repeat == 0) parts.add(dayLabel(LocalDate.ofEpochDay(r.epochDay)))
    parts.add(timesText(r))
    val rt = repeatText(r)
    if (rt.isNotEmpty()) parts.add(rt)
    if (r.category.isNotBlank()) parts.add(r.category)
    return parts.joinToString("  \u2022  ")
}

class Actions(
    private val ctx: Context,
    private val dao: ReminderDao,
    private val scope: CoroutineScope
) {
    fun toggleDone(r: Reminder) {
        scope.launch(Dispatchers.IO) {
            if (r.completed) {
                val back = r.copy(completed = false)
                dao.update(back)
                AlarmScheduler.schedule(ctx, back)
            } else {
                ReminderActions.complete(ctx, r.id)
            }
        }
    }

    fun delete(r: Reminder) {
        scope.launch(Dispatchers.IO) {
            AlarmScheduler.cancelAll(ctx, r.id)
            dao.delete(r)
        }
    }

    fun setEnabled(r: Reminder, on: Boolean) {
        scope.launch(Dispatchers.IO) {
            val n = r.copy(enabled = on)
            dao.update(n)
            if (on) AlarmScheduler.schedule(ctx, n) else AlarmScheduler.cancelAll(ctx, r.id)
        }
    }

    fun save(r: Reminder) {
        scope.launch(Dispatchers.IO) {
            val id = if (r.id == 0L) dao.insert(r) else { dao.update(r); r.id }
            AlarmScheduler.schedule(ctx, r.copy(id = id))
        }
    }

    fun testAlert() {
        scope.launch(Dispatchers.IO) {
            val n = LocalDateTime.now()
            val t = Reminder(
                title = "Test alert", notes = "Full-screen test",
                epochDay = n.toLocalDate().toEpochDay(),
                minuteOfDay = n.hour * 60 + n.minute, style = 2, priority = 3, category = "Other"
            )
            val id = dao.insert(t)
            AlarmScheduler.scheduleIn(ctx, t.copy(id = id), 10_000L)
        }
    }
}

object Perm {
    private fun go(c: Context, i: Intent) = c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    private fun pkg(c: Context) = Uri.parse("package:" + c.packageName)

    fun notifOk(c: Context) = NotificationManagerCompat.from(c).areNotificationsEnabled()
    fun exactOk(c: Context) = AlarmScheduler.canExact(c)
    fun fullOk(c: Context) = NotificationHelper.canFullScreen(c)
    fun overlayOk(c: Context) = Settings.canDrawOverlays(c)

    fun openNotif(c: Context) = go(
        c, Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)
    )

    fun openExact(c: Context) {
        if (Build.VERSION.SDK_INT >= 31) go(c, Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg(c)))
    }

    fun openFull(c: Context) {
        if (Build.VERSION.SDK_INT >= 34) go(c, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg(c)))
    }

    fun openOverlay(c: Context) = go(c, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg(c)))
    fun openAppInfo(c: Context) = go(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg(c)))
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 8.dp)
    )
}

@Composable
fun WarnCard(text: String, button: String, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4E0))
    ) {
        Row(
            Modifier.padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text, Modifier.weight(1f), color = Color(0xFF5B3B00), fontSize = 14.sp)
            TextButton(onClick = onClick) { Text(button) }
        }
    }
}

@Composable
fun ChipRow(label: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Column {
        Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            options.forEachIndexed { i, text ->
                FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(text) })
            }
        }
    }
}

@Composable
fun ReminderCard(r: Reminder, subtitle: String, actions: Actions, onEdit: (Reminder) -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth().clickable { onEdit(r) }
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { actions.toggleDone(r) }) {
                Box(
                    Modifier.size(26.dp).clip(CircleShape)
                        .background(
                            if (r.completed) MaterialTheme.colorScheme.primary
                            else priorityColors[r.priority.coerceIn(0, 3)].copy(alpha = 0.25f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (r.completed) {
                        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
            Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                Text(
                    r.title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    textDecoration = if (r.completed) TextDecoration.LineThrough else null
                )
                Text(subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box(Modifier.size(10.dp).clip(CircleShape).background(priorityColors[r.priority.coerceIn(0, 3)]))
            IconButton(onClick = { actions.delete(r) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete")
            }
        }
    }
}
