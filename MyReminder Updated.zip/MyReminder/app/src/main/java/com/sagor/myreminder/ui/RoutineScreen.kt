package com.sagor.myreminder.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.data.allTimes

@Composable
fun RoutineRow(r: Reminder, actions: Actions, onEdit: (Reminder) -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth().clickable { onEdit(r) }
    ) {
        Row(
            Modifier.padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(timesText(r), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(r.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                val rt = repeatText(r)
                Text(
                    (if (rt.isEmpty()) "" else rt + "  \u2022  ") + r.category,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { actions.delete(r) }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
            Switch(checked = r.enabled, onCheckedChange = { actions.setEnabled(r, it) })
        }
    }
}

@Composable
fun RoutineScreen(all: List<Reminder>, actions: Actions, onEdit: (Reminder) -> Unit, pad: PaddingValues) {
    val routines = all.filter { it.isRoutine }.sortedBy { it.allTimes().first() }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Daily Routine", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(
                "Your repeating habits. Each one has its own time, days and alert style.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (routines.isEmpty()) {
            item {
                Text(
                    "No routines yet. Tap + and try something like 6:00 AM Wake up, or 10:00 PM Plan tomorrow.",
                    modifier = Modifier.padding(top = 16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        items(routines, key = { it.id }) { r -> RoutineRow(r, actions, onEdit) }
        item { Spacer(Modifier.height(72.dp)) }
    }
}
