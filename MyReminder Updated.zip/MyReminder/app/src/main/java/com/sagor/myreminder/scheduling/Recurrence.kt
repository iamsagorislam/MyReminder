package com.sagor.myreminder.scheduling

import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.data.allTimes
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.ChronoUnit

object Recurrence {
    /** Does this reminder fall on day [d]? */
    fun occursOn(r: Reminder, d: LocalDate): Boolean = matches(r, LocalDate.ofEpochDay(r.epochDay), d)

    private fun matches(r: Reminder, base: LocalDate, d: LocalDate): Boolean {
        if (d.isBefore(base)) return false
        return when (r.repeat) {
            0 -> d == base
            1 -> true
            2 -> d.dayOfWeek == base.dayOfWeek
            3 -> d.dayOfWeek.value <= 5
            4 -> d.dayOfWeek.value >= 6
            5 -> d.dayOfMonth == minOf(base.dayOfMonth, d.lengthOfMonth())
            6 -> ChronoUnit.DAYS.between(base, d) % maxOf(1, r.intervalDays) == 0L
            7 -> ((r.daysMask shr (d.dayOfWeek.value - 1)) and 1) == 1
            else -> false
        }
    }

    /** Next trigger strictly after [now], or null if nothing is left. */
    fun next(r: Reminder, now: LocalDateTime = LocalDateTime.now()): LocalDateTime? {
        val base = LocalDate.ofEpochDay(r.epochDay)
        val times = r.allTimes().map { LocalTime.of(it / 60, it % 60) }
        if (r.repeat == 0) {
            return times.map { LocalDateTime.of(base, it) }.firstOrNull { it.isAfter(now) }
        }
        var d = if (now.toLocalDate().isAfter(base)) now.toLocalDate() else base
        for (i in 0..400) {
            if (matches(r, base, d)) {
                val c = times.map { LocalDateTime.of(d, it) }.firstOrNull { it.isAfter(now) }
                if (c != null) return c
            }
            d = d.plusDays(1)
        }
        return null
    }
}
