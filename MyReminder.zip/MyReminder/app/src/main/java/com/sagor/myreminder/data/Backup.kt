package com.sagor.myreminder.data

import org.json.JSONArray
import org.json.JSONObject

object Backup {
    fun toJson(list: List<Reminder>, categories: List<String>): String {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(
                JSONObject().apply {
                    put("title", r.title)
                    put("notes", r.notes)
                    put("epochDay", r.epochDay)
                    put("minuteOfDay", r.minuteOfDay)
                    put("repeat", r.repeat)
                    put("priority", r.priority)
                    put("style", r.style)
                    put("completed", r.completed)
                    put("nagEnabled", r.nagEnabled)
                    put("nagMinutes", r.nagMinutes)
                    put("extraTimes", r.extraTimes)
                    put("category", r.category)
                    put("isRoutine", r.isRoutine)
                    put("enabled", r.enabled)
                    put("daysMask", r.daysMask)
                    put("intervalDays", r.intervalDays)
                }
            )
        }
        val cats = JSONArray()
        categories.forEach { cats.put(it) }
        return JSONObject()
            .put("app", "MyReminder")
            .put("version", 1)
            .put("reminders", arr)
            .put("categories", cats)
            .toString(2)
    }

    fun fromJson(text: String): Pair<List<Reminder>, List<String>> {
        val o = JSONObject(text)
        val arr = o.getJSONArray("reminders")
        val list = (0 until arr.length()).map { i ->
            val j = arr.getJSONObject(i)
            Reminder(
                title = j.getString("title"),
                notes = j.optString("notes", ""),
                epochDay = j.getLong("epochDay"),
                minuteOfDay = j.getInt("minuteOfDay"),
                repeat = j.optInt("repeat", 0),
                priority = j.optInt("priority", 1),
                style = j.optInt("style", 1),
                completed = j.optBoolean("completed", false),
                nagEnabled = j.optBoolean("nagEnabled", false),
                nagMinutes = j.optInt("nagMinutes", 15),
                extraTimes = j.optString("extraTimes", ""),
                category = j.optString("category", "Personal"),
                isRoutine = j.optBoolean("isRoutine", false),
                enabled = j.optBoolean("enabled", true),
                daysMask = j.optInt("daysMask", 0),
                intervalDays = j.optInt("intervalDays", 1)
            )
        }
        val cats = o.optJSONArray("categories")
        val catList = if (cats == null) emptyList() else (0 until cats.length()).map { cats.getString(it) }
        return list to catList
    }
}
