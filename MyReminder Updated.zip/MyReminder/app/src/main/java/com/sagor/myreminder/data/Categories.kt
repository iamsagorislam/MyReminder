package com.sagor.myreminder.data

import android.content.Context

object Categories {
    val defaults = listOf("Personal", "Work", "Business", "Health & Fitness", "Important", "Other")

    private fun prefs(c: Context) = c.getSharedPreferences("categories", Context.MODE_PRIVATE)

    fun custom(c: Context): List<String> =
        (prefs(c).getStringSet("custom", emptySet()) ?: emptySet()).toList().sorted()

    fun all(c: Context): List<String> = defaults + custom(c)

    fun add(c: Context, name: String) {
        val n = name.trim()
        if (n.isEmpty() || n in all(c)) return
        val s = (prefs(c).getStringSet("custom", emptySet()) ?: emptySet()).toMutableSet()
        s.add(n)
        prefs(c).edit().putStringSet("custom", s).apply()
    }

    fun remove(c: Context, name: String) {
        val s = (prefs(c).getStringSet("custom", emptySet()) ?: emptySet()).toMutableSet()
        s.remove(name)
        prefs(c).edit().putStringSet("custom", s).apply()
    }
}
