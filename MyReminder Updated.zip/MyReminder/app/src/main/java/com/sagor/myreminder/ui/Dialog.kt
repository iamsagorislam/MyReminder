package com.sagor.myreminder.ui

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.app.TimePickerDialog
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sagor.myreminder.data.Categories
import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.data.CheckItem
import com.sagor.myreminder.data.allTimes
import com.sagor.myreminder.data.checkItems
import com.sagor.myreminder.data.encodeChecklist
import com.sagor.myreminder.notifications.NotificationHelper
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun ReminderDialog(
    initial: Reminder?,
    routine: Boolean,
    onDismiss: () -> Unit,
    onSave: (Reminder) -> Unit
) {
    val ctx = LocalContext.current
    val baseCategories = remember { Categories.all(ctx) }
    val start = remember { LocalDateTime.now().plusHours(1).withMinute(0).withSecond(0) }

    var title by remember { mutableStateOf(initial?.title ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var date by remember {
        mutableStateOf(initial?.let { LocalDate.ofEpochDay(it.epochDay) } ?: start.toLocalDate())
    }
    val times = remember {
        mutableStateListOf<Int>().apply { addAll(initial?.allTimes() ?: listOf(start.hour * 60)) }
    }
    var repeat by remember { mutableIntStateOf(initial?.repeat ?: (if (routine) 1 else 0)) }
    var priority by remember { mutableIntStateOf(initial?.priority ?: 1) }
    var style by remember { mutableIntStateOf(initial?.style ?: 1) }
    var nag by remember { mutableStateOf(initial?.nagEnabled ?: false) }
    var category by remember { mutableStateOf(initial?.category ?: "Personal") }
    var mask by remember { mutableIntStateOf(initial?.daysMask ?: 0) }
    var interval by remember { mutableStateOf((initial?.intervalDays ?: 2).toString()) }

    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    val items = remember {
        mutableStateListOf<CheckItem>().apply { addAll(initial?.checkItems() ?: emptyList()) }
    }
    val pickContact = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) {
            try {
                ctx.contentResolver.query(
                    uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null
                )?.use { cur -> if (cur.moveToFirst()) phone = cur.getString(0) ?: "" }
            } catch (e: Exception) {
                // ignore, the number can be typed
            }
        }
    }
    val isNew = initial == null || initial.id == 0L

    val categories = if (category in baseCategories) baseCategories else baseCategories + category
    val isRoutine = routine || initial?.isRoutine == true
    val canSave = title.isNotBlank() && !(repeat == 7 && mask == 0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    isNew && isRoutine -> "New routine"
                    isNew -> "New reminder"
                    isRoutine -> "Edit routine"
                    else -> "Edit reminder"
                }
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text(if (isRoutine) "Routine name" else "What do you need to do?") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes, onValueChange = { notes = it },
                    label = { Text("Notes (optional)") }, modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = phone, onValueChange = { phone = it },
                        label = { Text("Phone for call or WhatsApp (optional)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        try {
                            pickContact.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
                        } catch (e: Exception) {
                            // no contacts app
                        }
                    }) { Text("Contact") }
                }
                Text("Checklist", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                items.forEachIndexed { i, item ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = item.done, onCheckedChange = { items[i] = item.copy(done = it) })
                        OutlinedTextField(
                            value = item.text,
                            onValueChange = { items[i] = item.copy(text = it) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { items.removeAt(i) }) { Text("X") }
                    }
                }
                OutlinedButton(onClick = { items.add(CheckItem(false, "")) }) { Text("+ Add checklist item") }
                OutlinedButton(onClick = {
                    DatePickerDialog(
                        ctx, { _, y, m, d -> date = LocalDate.of(y, m + 1, d) },
                        date.year, date.monthValue - 1, date.dayOfMonth
                    ).show()
                }) {
                    Text((if (isRoutine) "Starts " else "") + date.format(DateTimeFormatter.ofPattern("EEE, d MMM")))
                }
                Text("Remind me at", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                times.forEachIndexed { index, t ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            TimePickerDialog(ctx, { _, h, m -> times[index] = h * 60 + m }, t / 60, t % 60, false).show()
                        }) { Text(NotificationHelper.timeText(t)) }
                        if (times.size > 1) TextButton(onClick = { times.removeAt(index) }) { Text("Remove") }
                    }
                }
                OutlinedButton(onClick = {
                    val last = times.last()
                    TimePickerDialog(ctx, { _, h, m -> times.add(h * 60 + m) }, last / 60, last % 60, false).show()
                }) { Text("+ Add another time") }

                ChipRow("Repeat", repeatLabels, repeat) { repeat = it }
                if (repeat == 6) {
                    OutlinedTextField(
                        value = interval,
                        onValueChange = { interval = it.filter(Char::isDigit).take(3) },
                        label = { Text("Every how many days?") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (repeat == 7) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        dayLabels.forEachIndexed { i, l ->
                            FilterChip(
                                selected = ((mask shr i) and 1) == 1,
                                onClick = { mask = mask xor (1 shl i) },
                                label = { Text(l) }
                            )
                        }
                    }
                }
                ChipRow("Category", categories, categories.indexOf(category).coerceAtLeast(0)) { category = categories[it] }
                ChipRow("Priority", priorityLabels, priority) { priority = it }
                ChipRow("How should it alert?", styleLabels, style) { style = it }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Remind again every 15 min if not done (max 3 times)", Modifier.weight(1f), fontSize = 14.sp)
                    Switch(checked = nag, onCheckedChange = { nag = it })
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = canSave,
                onClick = {
                    val sorted = times.distinct().sorted()
                    onSave(
                        Reminder(
                            id = initial?.id ?: 0,
                            title = title.trim(),
                            notes = notes.trim(),
                            epochDay = date.toEpochDay(),
                            minuteOfDay = sorted.first(),
                            extraTimes = sorted.drop(1).joinToString(","),
                            repeat = repeat,
                            priority = priority,
                            style = style,
                            completed = false,
                            nagEnabled = nag,
                            nagMinutes = 15,
                            category = category,
                            isRoutine = isRoutine,
                            enabled = initial?.enabled ?: true,
                            daysMask = mask,
                            intervalDays = (interval.toIntOrNull() ?: 1).coerceIn(1, 365),
                            checklist = encodeChecklist(items.toList()),
                            phone = phone.trim()
                        )
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
