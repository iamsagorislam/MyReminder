package com.sagor.myreminder.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sagor.myreminder.data.Reminder
import com.sagor.myreminder.data.allTimes
import com.sagor.myreminder.notifications.NotificationHelper
import com.sagor.myreminder.scheduling.Recurrence
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

private fun untilText(now: LocalDateTime, t: LocalDateTime): String {
    val m = ChronoUnit.MINUTES.between(now, t)
    return when {
        m < 1 -> "now"
        m < 60 -> "in $m min"
        m < 1440 -> "in " + (m / 60) + "h " + (m % 60) + "m"
        else -> "in " + (m / 1440) + " days"
    }
}

@Composable
private fun StatCard(label: String, value: Int, accent: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value.toString(), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = accent)
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun LazyListScope.block(
    title: String,
    list: List<Reminder>,
    actions: Actions,
    onEdit: (Reminder) -> Unit
) {
    if (list.isEmpty()) return
    item(key = "h_$title") { SectionTitle(title) }
    items(list, key = { title + it.id }) { r -> ReminderCard(r, subtitleFor(r, true), actions, onEdit) }
}

@Composable
fun HomeScreen(
    all: List<Reminder>,
    tick: Int,
    actions: Actions,
    onEdit: (Reminder) -> Unit,
    onVoice: () -> Unit,
    pad: PaddingValues
) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000)
            now = LocalDateTime.now()
        }
    }
    val today = now.toLocalDate()
    val active = all.filter { it.enabled && !it.completed }
    val overdue = all.filter { isOverdue(it, now) }
    val todayTasks = active
        .filter { !it.isRoutine && it !in overdue && Recurrence.occursOn(it, today) }
        .sortedBy { it.allTimes().first() }
    val routineToday = active
        .filter { it.isRoutine && Recurrence.occursOn(it, today) }
        .sortedBy { it.allTimes().first() }
    val nextUp = active
        .mapNotNull { r -> Recurrence.next(r, now)?.let { t -> r to t } }
        .minByOrNull { it.second }
    val pending = active.count { !it.isRoutine }
    val done = all.count { it.completed }

    val notifOk = remember(tick) { Perm.notifOk(ctx) }
    val exactOk = remember(tick) { Perm.exactOk(ctx) }
    val fullOk = remember(tick) { Perm.fullOk(ctx) }
    val overlayOk = remember(tick) { Perm.overlayOk(ctx) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                now.format(DateTimeFormatter.ofPattern("h:mm a")),
                fontSize = 44.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                today.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        item {
            FilledTonalButton(onClick = onVoice) { Text("\uD83C\uDFA4  \u09AC\u09BE\u0982\u09B2\u09BE\u09DF \u09AC\u09B2\u09CB") }
        }
        if (!notifOk) item { WarnCard("Notifications are blocked. Reminders cannot appear.", "Allow") { Perm.openNotif(ctx) } }
        if (!exactOk) item { WarnCard("Exact alarms are off. Reminders may arrive late.", "Allow") { Perm.openExact(ctx) } }
        if (!fullOk) item { WarnCard("Full-screen alerts are off for locked screens.", "Allow") { Perm.openFull(ctx) } }
        if (!overlayOk) item {
            WarnCard("Allow \"Display over other apps\" so alarms can cover the screen while you use the phone.", "Allow") {
                Perm.openOverlay(ctx)
            }
        }
        item {
            val n = nextUp
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth().clickable(enabled = n != null) { n?.let { onEdit(it.first) } }
            ) {
                Column(Modifier.padding(20.dp)) {
                    val on = MaterialTheme.colorScheme.onPrimary
                    Text("NEXT UP", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = on.copy(alpha = 0.75f))
                    if (n == null) {
                        Text("Nothing scheduled", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = on)
                    } else {
                        Text(n.first.title, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = on)
                        Text(
                            untilText(now, n.second) + "  \u2022  " +
                                NotificationHelper.timeText(n.second.hour * 60 + n.second.minute),
                            color = on.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Overdue", overdue.size, Color(0xFFE5393B), Modifier.weight(1f))
                StatCard("Today", todayTasks.size, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                StatCard("Pending", pending, Color(0xFFF59E0B), Modifier.weight(1f))
                StatCard("Done", done, Color(0xFF2E9E5B), Modifier.weight(1f))
            }
        }
        if (all.isEmpty()) {
            item {
                Text(
                    "Nothing yet. Tap + to add your first reminder.",
                    modifier = Modifier.padding(top = 24.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        block("Overdue", overdue, actions, onEdit)
        block("Today's tasks", todayTasks, actions, onEdit)
        if (routineToday.isNotEmpty()) {
            item(key = "h_routine") { SectionTitle("Daily routine today") }
            items(routineToday, key = { "r" + it.id }) { r -> RoutineRow(r, actions, onEdit) }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}
